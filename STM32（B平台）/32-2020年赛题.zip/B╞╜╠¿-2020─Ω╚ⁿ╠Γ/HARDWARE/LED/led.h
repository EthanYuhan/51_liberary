#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
//////////////////////////////////////////////////////////////////////////////////	 

//LED��������	   
									  
////////////////////////////////////////////////////////////////////////////////// 
//PA15   
#define LED0 PAout(15)// 
//#define LED1 PDout(15)// 
//#define LED2 PDout(0)// 
//#define LED3 PDout(1)// 
//#define LED4 PEout(7)// 
//#define LED5 PEout(8)// 
//#define LED6 PEout(9)// 
//#define LED7 PEout(10)// 



void LED_Init(void);//��ʼ��

		 				    
#endif
